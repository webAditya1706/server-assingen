const ragisterUser = require("../models/ragisterUser")
const cloudnary = require("cloudinary").v2
const bycript = require("bcrypt")

const userControllers = {
	ragister: async (req, res) => {
		const saltround = 5;
		const newUser = new ragisterUser(req.body);
		newUser.password = await bycript.hash(newUser.password, saltround)

		try {
			if (req.file) {
				const result = await cloudnary.uploader.upload(req.file.path, {
					folder: "crud-with-men_2"
				})
				newUser.logo = result.url
				newUser.save();
				res.status(200).json({
					sucess: true,
					message: "User Ragistered",
					data: newUser
				})
			} else {
				newUser.save();
				res.status(200).json({
					sucess: true,
					message: "User Ragistered",
					data: newUser
				})
			}
		} catch (error) {
			res.status(500).json({
				sucess: false,
				message: "User not Ragistered",
				data: error
			})
		}
	},
	getAllData: async (req, res) => {
		try {
			const allData = await ragisterUser.find()
			if (allData) {
				res.status(200).json({
					sucess: true,
					message: "All ragistered users",
					data: allData
				})
			}
		} catch (error) {
			res.status(500).json({
				sucess: false,
				message: "Something went wrong",
				data: error
			})
		}
	},
	ragisterUserDelete: async (req, res) => {
		const { id } = req.params
		try {
			const allData = await ragisterUser.findByIdAndDelete(id)
			if (allData) {
				res.status(200).json({
					sucess: true,
					message: "Ragistered user deleted",
					data: allData
				})
			} else {
				res.status(400).json({
					sucess: false,
					message: "Id not found",
					data: error
				})
			}
		} catch (error) {
			res.status(500).json({
				sucess: false,
				message: "Id not found",
				data: error
			})
		}
	},
	ragisterUpdateUser: async (req, res) => {
		const { id } = req.params;
		const { body } = req;
		const salt = 5;

		body.password = await bycript.hash(body.password, salt)
		console.log(id, "========id");
		let updatedData;
		try {
			if (req?.file) {
				const imagePath = await cloudnary.uploader.upload(req?.file?.path, {
					folder: "crud-with-men_2"
				})
				body.logo = imagePath.url
				updatedData = await ragisterUser.findByIdAndUpdate(id, body)
				console.log(updatedData, "========updatedData path");

				return res.status(200).json({
					sucess: true,
					message: "User updated",
					data: body
				})
			} else {
				updatedData = await ragisterUser.findByIdAndUpdate(id, body);
				console.log(updatedData, "========updatedData");

				return res.status(200).json({
					sucess: true,
					message: "User updated",
					data: body
				})
			}

		} catch (error) {
			res.status(500).json({
				sucess: false,
				message: "Id not found",
				data: error
			})
		}
	}
}

module.exports = userControllers;