import chai from 'chai';
import chaiHttp from 'chai-http';
import app from '../server'; // Adjust the path according to your project structure

chai.use(chaiHttp);
const should = chai.should();
describe('Items', () => {
    before((done) => {
        mongoose.connection.collections.items.drop(() => {
            done();
        });
    });

    describe('/POST user/ragister', () => {
        it('it should POST a new item', (done) => {
            const item = {
                name: 'Test Item',
                description: 'This is a test item'
            };
            chai.request(app)
                .post('/user/ragister')
                .send(item)
                .end((err, res) => {
                    res.should.have.status(201);
                    res.body.should.be.a('object');
                    res.body.should.have.property('name').eql('Test Item');
                    res.body.should.have.property('description').eql('This is a test item');
                    done();
                });
        });
    });

    describe('/GET user/getAllData', () => {
        it('it should GET all the items', (done) => {
            chai.request(app)
                .get('/user/getAllData')
                .end((err, res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('array');
                    done();
                });
        });
    });

    describe('/GET/:id item', () => {
        it('it should GET an item by the given id', (done) => {
            const item = new mongoose.model('Item')({ name: 'Test Item', description: 'This is a test item' });
            item.save((err, item) => {
                chai.request(app)
                    .get(`/items/${item.id}`)
                    .send(item)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('object');
                        res.body.should.have.property('name').eql('Test Item');
                        res.body.should.have.property('description').eql('This is a test item');
                        res.body.should.have.property('_id').eql(item.id);
                        done();
                    });
            });
        });
    });

    describe('/PUT/:id item', () => {
        it('it should UPDATE an item given the id', (done) => {
            const item = new mongoose.model('Item')({ name: 'Test Item', description: 'This is a test item' });
            item.save((err, item) => {
                chai.request(app)
                    .put(`/items/${item.id}`)
                    .send({ name: 'Updated Item', description: 'This is an updated item' })
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('object');
                        res.body.should.have.property('name').eql('Updated Item');
                        res.body.should.have.property('description').eql('This is an updated item');
                        done();
                    });
            });
        });
    });

    describe('/DELETE/:id item', () => {
        it('it should DELETE an item given the id', (done) => {
            const item = new mongoose.model('Item')({ name: 'Test Item', description: 'This is a test item' });
            item.save((err, item) => {
                chai.request(app)
                    .delete(`/items/${item.id}`)
                    .end((err, res) => {
                        res.should.have.status(204);
                        done();
                    });
            });
        });
    });
});
